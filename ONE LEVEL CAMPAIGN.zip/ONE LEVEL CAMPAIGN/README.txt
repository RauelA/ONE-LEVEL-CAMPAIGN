
			    *** ONE LEVEL CAMPAIGN ***

			(by Rauel Anders aka 'Floatland Games')


	The ONE LEVEL CAMPAIGN is a Dungeon Keeper Level, that contains nearly
	everything the game has to offer. Starting with a small tutorial, the
       level will lead you through adventurous chapters against different types
			of enemies, resulting in a epic final.

	 The level will need the own created text files, which are available
		  in two possible languages: ENGLISH or GERMAN.

	(You can change the language in the FX-Launcher, but make sure, you've
	added the .dat-files in the 'fxdata'-folder. Don't worry! The original
      files are inside the given folder as well, in case you want to change back)


	HOW TO PLAY:

	Step 1: Make a backup (Just for safety)

	Step 2: Copy the 'fxdata'- and 'levels'-folder in your DK-installation.

	Step 3: Choose 'English' or 'German' in your FX-Launcher.

	Step 4: In-game, select "ONE LEVEL CAMPAIGN" in "Personal Levels".

	Step 5: Have fun! :)